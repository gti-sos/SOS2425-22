import{q as a}from"./5T3b_xH8.js";a();
